# modules/nvidia_ai.py

import asyncio
import base64
import requests
from pyrogram import filters
from pyrogram.types import Message
from pyrogram.handlers import MessageHandler

# ===== CONFIG =====
API_URL = "https://integrate.api.nvidia.com/v1/chat/completions"
API_KEY = "YOUR_NVIDIA_API_KEY"  # 🔴 replace

MODEL = "qwen/qwen3.5-122b-a10b"

# ===== HEADERS =====
def get_headers(stream=True):
    return {
        "Authorization": f"Bearer {API_KEY}",
        "Accept": "text/event-stream" if stream else "application/json"
    }

# ===== CORE AI FUNCTION =====
def ask_nvidia(prompt: str):
    payload = {
        "model": MODEL,
        "messages": [{"role": "user", "content": prompt}],
        "max_tokens": 4096,
        "temperature": 0.6,
        "top_p": 0.95,
        "stream": True,
        "chat_template_kwargs": {"enable_thinking": True},
    }

    try:
        response = requests.post(
            API_URL,
            headers=get_headers(True),
            json=payload,
            stream=True,
            timeout=60
        )

        result = ""

        for line in response.iter_lines():
            if line:
                decoded = line.decode("utf-8")

                # filter SSE noise
                if decoded.startswith("data: "):
                    data = decoded[6:]

                    if data == "[DONE]":
                        break

                    try:
                        import json
                        chunk = json.loads(data)

                        delta = chunk.get("choices", [{}])[0].get("delta", {})
                        content = delta.get("content")

                        if content:
                            result += content
                    except:
                        continue

        return result.strip()

    except Exception as e:
        return f"⚠️ Error: {str(e)}"


# ===== COMMAND HANDLER =====
async def ai_handler(client, message: Message):
    if len(message.command) < 2:
        return await message.reply("❌ Give a prompt")

    prompt = message.text.split(None, 1)[1]

    msg = await message.reply("🤖 Thinking...")

    loop = asyncio.get_event_loop()
    reply = await loop.run_in_executor(None, ask_nvidia, prompt)

    if not reply:
        reply = "⚠️ No response from AI"

    # Telegram limit safety
    if len(reply) > 4000:
        reply = reply[:4000] + "\n\n... (truncated)"

    await msg.edit(reply)


# ===== REGISTER =====
def init(app):
    app.add_handler(MessageHandler(ai_handler, filters.command("ai", ".") & filters.me))